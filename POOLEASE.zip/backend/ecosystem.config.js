module.exports = {
  apps: [
    {
      name: 'poolease-backend',
      script: 'backend/app.js',
      env: {
        NODE_ENV: 'development',
        PORT: 3001
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3001
      }
    },
    {
      name: 'poolease-frontend',
      script: 'node_modules/react-scripts/scripts/start.js',
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000
      }
    }
  ]
};
