import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Root2 from "./pages/Root2";
import Root1 from "./pages/Root1";
import Frame from "./pages/Frame";
import Root3 from "./pages/Root3"; // 修正导入
import Desktop from "./pages/Desktop";
import Root11 from "./pages/Root11"; // 修正导入
import Root21 from "./pages/Root21"; // 修正导入
import OtrasConsultas from "./pages/OtrasConsultas";
import Root from "./pages/Root"; // 修正导入

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "Home";
        metaDescription = "Welcome to the homepage.";
        break;
      case "/root1":
        title = "Root1";
        metaDescription = "Description for Root1.";
        break;
      case "/root2":
        title = "Root2";
        metaDescription = "Description for Root2.";
        break;
      case "/desktop":
        title = "Desktop";
        metaDescription = "Description for Desktop.";
        break;
      case "/root3":
        title = "Root3";
        metaDescription = "Description for Root3.";
        break;
      case "/root4":
        title = "Root4";
        metaDescription = "Description for Root4.";
        break;
      case "/otras-consultas":
        title = "Otras Consultas";
        metaDescription = "Description for Otras Consultas.";
        break;
      case "/root":
        title = "Root";
        metaDescription = "Description for Root.";
        break;
      default:
        title = "Page Not Found";
        metaDescription = "The page you are looking for does not exist.";
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  // 检查是否在 Electron 环境中
  const isElectron = () => {
    // 检查 Node.js 的特定属性
    return !!(window && window.process && window.process.type);
  };

  if (!isElectron()) {
    return (
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h1>该应用只能在 Electron 中运行</h1>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Frame />} />
      <Route path="/1" element={<Root1 />} />
      <Route path="/2" element={<Root2 />} />
      <Route path="/3" element={<Desktop />} />
      <Route path="/4" element={<Root3 />} />
      <Route path="/5" element={<Root21 />} />
      <Route path="/6" element={<OtrasConsultas />} />
      <Route path="/7" element={<Root />} />
    </Routes>
  );
}

export default App;
