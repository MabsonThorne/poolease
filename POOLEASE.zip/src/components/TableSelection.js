import React, { useState } from "react";
import PropTypes from "prop-types";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const TableSelection = ({ className = "", headerSeparator }) => {
  const [selectedTable, setSelectedTable] = useState(null);
  const tables = Array.from({ length: 20 }, (_, i) => i + 1);
  const [activeTable, setActiveTable] = useState(null);

  const handleTableClick = (tableNumber) => {
    if (activeTable === tableNumber) {
      console.log(`Navigate to panel for table ${tableNumber}`);
    } else {
      setSelectedTable(tableNumber);
    }
  };

  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    adaptiveHeight: true
  };

  return (
    <div
      className={`w-full rounded-xl bg-background-default-default flex flex-col items-center justify-start p-4 gap-4 ${className}`}
    >
      <div className="w-full text-2xl text-black-100 font-body-base mb-4">
        <span>请选择台号</span>
        <span className="text-xl">（左滑选择更多）</span>
      </div>
      <img
        className="self-stretch relative max-w-full overflow-hidden max-h-full object-contain z-[2]"
        alt=""
        src={headerSeparator}
      />
      <Slider {...settings} className="w-full">
        {tables.map((table) => (
          <div key={table} className="p-2">
            <div
              className={`w-full h-24 flex items-center justify-center rounded-lg cursor-pointer
                ${activeTable === table ? "bg-red-600 border-black" :
                  selectedTable === table ? "bg-black-100 text-white" :
                    "bg-white border-black"}`}
              onClick={() => handleTableClick(table)}
              style={{ borderWidth: 1 }}
            >
              {table}
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

TableSelection.propTypes = {
  className: PropTypes.string,
  headerSeparator: PropTypes.string,
};

export default TableSelection;
