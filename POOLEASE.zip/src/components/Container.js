import PropTypes from "prop-types";

const Container = ({ className = "" }) => {
  return (
    <div
      className={`w-[647px] rounded-xl bg-background-default-default flex flex-col items-end justify-start pt-[82px] px-10 pb-[75px] box-border gap-[34px] min-w-[647px] max-w-full z-[2] text-left text-base text-gray-200 font-body-base mq450:pt-[34px] mq450:pb-8 mq450:box-border mq1150:flex-1 mq750:gap-[17px] mq1050:pt-[53px] mq1050:pb-[49px] mq1050:box-border mq1050:min-w-full ${className}`}
    >
      <div className="w-[647px] h-[905px] relative rounded-xl bg-background-default-default hidden max-w-full" />
      <div className="w-[543px] flex flex-row items-start justify-start gap-[24px] max-w-full text-13xl mq750:flex-wrap">
        <div className="flex-1 rounded-3xs bg-background-default-default box-border flex flex-row items-start justify-start py-0 px-[26px] min-w-[192px] max-w-full z-[3] border-[1px] border-solid border-black-100">
          <div className="h-10 w-[406px] relative rounded-3xs bg-background-default-default box-border hidden max-w-full border-[1px] border-solid border-black-100" />
          <h1 className="m-0 relative text-inherit font-normal font-inherit z-[4] mq450:text-lgi mq1050:text-7xl">
            请输入商品名
          </h1>
        </div>
        <button className="cursor-pointer py-2.5 pr-[39px] pl-10 bg-background-brand-default rounded-radius-200 overflow-hidden flex flex-row items-start justify-start gap-[8px] z-[3] border-[1px] border-solid border-background-brand-default">
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/star4.svg"
          />
          <div className="relative text-base leading-[100%] font-body-base text-text-brand-on-brand text-left inline-block min-w-[32px]">
            搜索
          </div>
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/x5.svg"
          />
        </button>
      </div>
      <div className="rounded-3xs box-border overflow-x-auto flex flex-row items-start justify-start gap-[16px] max-w-full z-[3] text-text-neutral-default border-[1px] border-solid border-black-100">
        <button className="cursor-pointer py-2.5 pr-[31px] pl-8 bg-black-100 rounded-radius-200 overflow-hidden shrink-0 flex flex-row items-start justify-start gap-[8px] border-[1px] border-solid border-black-100">
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/star2.svg"
          />
          <div className="relative text-base leading-[100%] font-body-base text-background-default-default text-left inline-block min-w-[32px]">
            饮品
          </div>
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/x2.svg"
          />
        </button>
        <div className="rounded-radius-200 overflow-hidden shrink-0 flex flex-row items-start justify-start py-space-300 px-8 gap-[8px]">
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/star2.svg"
          />
          <div className="relative leading-[100%] inline-block min-w-[32px]">
            零食
          </div>
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/x2.svg"
          />
        </div>
        <div className="rounded-radius-200 overflow-hidden shrink-0 flex flex-row items-start justify-start py-space-300 px-8 gap-[8px]">
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/star2.svg"
          />
          <div className="relative leading-[100%] inline-block min-w-[32px]">
            香烟
          </div>
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/x2.svg"
          />
        </div>
        <div className="rounded-radius-200 overflow-hidden shrink-0 flex flex-row items-start justify-start py-space-300 px-8 gap-[8px]">
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/star2.svg"
          />
          <div className="relative leading-[100%] inline-block min-w-[32px]">
            纸巾
          </div>
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/x2.svg"
          />
        </div>
        <div className="rounded-radius-200 overflow-hidden shrink-0 flex flex-row items-start justify-start py-space-300 px-8 gap-[8px] text-black-100">
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/star3.svg"
          />
          <div className="relative leading-[100%] inline-block min-w-[32px]">
            其他
          </div>
          <img
            className="h-4 w-4 relative overflow-hidden shrink-0 hidden min-h-[16px]"
            alt=""
            src="/x3.svg"
          />
        </div>
      </div>
      <div className="mr-[-70px] w-[637px] flex flex-col items-start justify-start pt-0 px-0 pb-[419px] box-border gap-[26px] max-w-[113%] shrink-0 text-darkslategray font-rubik mq750:pb-[272px] mq750:box-border">
        <div className="self-stretch h-8 relative">
          <div className="absolute top-[0px] left-[0px] bg-gray-100 w-[598px] h-8 z-[3]" />
          <div className="absolute top-[8px] left-[385px] leading-[24px] text-lightslategray-200 flex items-center w-[120px] h-6 z-[4]">
            进价
          </div>
          <div className="absolute top-[8px] left-[257px] leading-[24px] flex items-center w-8 h-6 min-w-[32px] z-[4]">
            数量
          </div>
          <div className="absolute top-[8px] left-[517px] leading-[24px] flex items-center w-[120px] h-6 z-[4]">
            操作
          </div>
          <div className="absolute top-[7px] left-[146px] leading-[24px] text-lightslategray-200 flex items-center w-[111px] h-6 z-[5]">
            价格
          </div>
          <div className="absolute top-[7px] left-[24px] leading-[24px] flex items-center w-[122px] h-6 z-[6]">
            名称
          </div>
        </div>
        <div className="w-[598px] flex flex-col items-start justify-start gap-[13px] max-w-full">
          <div className="w-[569px] flex flex-row items-start justify-start py-0 px-6 box-border max-w-full">
            <div className="flex-1 flex flex-row items-end justify-start max-w-full [row-gap:20px] mq750:flex-wrap">
              <div className="flex-1 flex flex-col items-start justify-end pt-0 px-0 pb-0.5 box-border min-w-[79px]">
                <div className="self-stretch relative leading-[24px] z-[6]">
                  可乐
                </div>
              </div>
              <div className="flex-1 flex flex-col items-start justify-end pt-0 px-0 pb-px box-border min-w-[79px] text-lightslategray-200">
                <div className="self-stretch relative leading-[24px] z-[5]">
                  1.00
                </div>
              </div>
              <div className="flex-[0.8333] flex flex-col items-start justify-end pt-0 pb-px pr-5 pl-0 box-border min-w-[79px] mq450:flex-1">
                <div className="relative leading-[24px] inline-block min-w-[7px] z-[4]">
                  1
                </div>
              </div>
              <div className="flex-[0.9375] flex flex-col items-start justify-end pt-0 pb-[3px] pr-2 pl-0 box-border min-w-[83px] text-lightslategray-200 mq450:flex-1">
                <div className="self-stretch relative leading-[21px] z-[3]">
                  2.00
                </div>
              </div>
              <img
                className="h-8 w-8 relative overflow-hidden shrink-0 z-[3]"
                loading="lazy"
                alt=""
                src="/trash-2.svg"
              />
            </div>
          </div>
          <div className="self-stretch h-px relative bg-ghostwhite z-[3]" />
        </div>
      </div>
      <div className="self-stretch flex flex-row items-start justify-start py-0 px-[30px] box-border max-w-full text-text-default-default">
        <div className="w-[484px] flex flex-row items-center justify-start gap-[8px] max-w-full z-[3] mq750:flex-wrap">
          <div className="rounded-radius-200 flex flex-row items-center justify-center py-space-200 px-space-300 gap-[8px] opacity-[0.5] text-text-default-secondary">
            <img
              className="h-4 w-4 relative overflow-hidden shrink-0 min-h-[16px]"
              loading="lazy"
              alt=""
              src="/arrow-left.svg"
            />
            <div className="relative leading-[100%] inline-block min-w-[48px]">
              上一页
            </div>
          </div>
          <div className="flex-1 flex flex-row items-center justify-start gap-[8px] min-w-[270px]">
            <div className="rounded-radius-200 bg-background-brand-default flex flex-col items-center justify-center py-space-200 px-space-300 text-text-brand-on-brand">
              <div className="relative leading-[100%] inline-block min-w-[8px]">
                1
              </div>
            </div>
            <div className="rounded-radius-200 flex flex-col items-center justify-center py-space-200 px-space-300">
              <div className="relative leading-[100%] inline-block min-w-[10px]">
                2
              </div>
            </div>
            <div className="rounded-radius-200 flex flex-col items-center justify-center py-space-200 px-space-300">
              <div className="relative leading-[100%] inline-block min-w-[11px]">
                3
              </div>
            </div>
            <div className="flex-[0.6522] rounded-lg flex flex-col items-center justify-center py-space-200 px-space-400 text-black-100">
              <b className="relative leading-[140%] inline-block min-w-[15px]">
                ...
              </b>
            </div>
            <div className="flex-1 rounded-radius-200 flex flex-col items-center justify-center py-space-200 px-space-300">
              <div className="relative leading-[100%] inline-block min-w-[20px]">
                67
              </div>
            </div>
            <div className="flex-1 rounded-radius-200 flex flex-col items-center justify-center py-space-200 px-space-300">
              <div className="relative leading-[100%] inline-block min-w-[20px]">
                68
              </div>
            </div>
          </div>
          <div className="rounded-radius-200 flex flex-row items-center justify-center py-space-200 px-space-300 gap-[8px]">
            <div className="relative leading-[100%] inline-block min-w-[48px]">
              下一页
            </div>
            <img
              className="h-4 w-4 relative overflow-hidden shrink-0 min-h-[16px]"
              loading="lazy"
              alt=""
              src="/arrow-right.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

Container.propTypes = {
  className: PropTypes.string,
};

export default Container;
