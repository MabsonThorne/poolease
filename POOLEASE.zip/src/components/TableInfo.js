import ItemOne from "./ItemOne";
import PropTypes from "prop-types";

const TableInfo = ({ className = "" }) => {
  return (
    <div
      className={`flex-1 rounded-xl bg-background-default-default flex flex-col items-start justify-start py-[39px] pr-[51px] pl-[58px] box-border gap-[52px] min-w-[442px] max-w-full z-[1] text-left text-13xl text-black-100 font-body-base lg:pt-[25px] lg:pb-[25px] lg:box-border mq450:pt-5 mq450:pb-5 mq450:box-border mq825:gap-[26px] mq825:pl-[29px] mq825:pr-[25px] mq825:box-border mq825:min-w-full ${className}`}
    >
      <div className="w-[680px] h-[905px] relative rounded-xl bg-background-default-default hidden max-w-full" />
      <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-1 box-border max-w-full">
        <div className="flex-1 flex flex-col items-start justify-start gap-[30px] max-w-full lg:flex-1">
          <div className="self-stretch flex flex-col items-start justify-start pt-0 px-0 pb-1.5 box-border gap-[6px] max-w-full">
            <div className="self-stretch flex flex-col items-start justify-start gap-[47px] max-w-full mq825:gap-[23px]">
              <div className="self-stretch flex flex-row items-end justify-start gap-[9px] max-w-full mq825:flex-wrap">
                <div className="flex-1 flex flex-col items-start justify-start gap-[5.4px] min-w-[292px] max-w-full">
                  <div className="w-[335px] flex flex-row items-start justify-start gap-[37px] shrink-0 max-w-full mq450:flex-wrap mq450:gap-[18px]">
                    <a className="[text-decoration:none] flex-1 relative text-[inherit] inline-block min-w-[104px] z-[2] mq450:text-lgi mq825:text-7xl">
                      开台时间：
                    </a>
                    <a className="[text-decoration:none] relative text-red-200 whitespace-nowrap z-[2] mq450:text-lgi mq825:text-7xl">
                      00:00:00
                    </a>
                  </div>
                  <img
                    className="self-stretch relative max-w-full overflow-hidden max-h-full object-contain shrink-0 mt-[-1px] z-[2]"
                    loading="lazy"
                    alt=""
                    src="/line-2.svg"
                  />
                </div>
                <div className="flex flex-col items-start justify-end pt-0 px-0 pb-px">
                  <button className="cursor-pointer [border:none] py-3 px-[9px] bg-red-200 rounded-3xs flex flex-row items-start justify-start z-[2] hover:bg-red-100">
                    <div className="h-[42px] w-[108px] relative rounded-3xs bg-red-200 hidden" />
                    <a className="[text-decoration:none] relative text-mini font-body-base text-background-default-default text-left inline-block min-w-[90px] z-[3]">
                      点击停止计费
                    </a>
                  </button>
                </div>
              </div>
              <div className="flex flex-row items-start justify-start gap-[18px]">
                <h1 className="m-0 w-24 relative text-inherit font-normal font-inherit inline-block z-[2] mq450:text-lgi mq825:text-7xl">
                  台费：
                </h1>
                <div className="relative text-red-200 inline-block min-w-[120px] z-[2] mq450:text-lgi mq825:text-7xl">
                  ￥00.00
                </div>
              </div>
            </div>
            <img
              className="self-stretch relative max-w-full overflow-hidden max-h-full object-contain mt-[-1px] z-[2]"
              loading="lazy"
              alt=""
              src="/line-3.svg"
            />
          </div>
          <div className="self-stretch flex flex-row items-start justify-between pt-0 px-0 pb-1.5 gap-[20px] mq450:flex-wrap">
            <div className="flex flex-col items-start justify-start pt-[3px] px-0 pb-0">
              <h1 className="m-0 relative text-inherit font-normal font-inherit inline-block min-w-[128px] z-[2] mq450:text-lgi mq825:text-7xl">
                已选商品
              </h1>
            </div>
            <div className="rounded-3xs bg-black-100 flex flex-row items-start justify-start pt-[9px] pb-2.5 pr-[7px] pl-[9px] gap-[9px] z-[2] text-mini text-background-default-default">
              <div className="h-[42px] w-[108px] relative rounded-3xs bg-black-100 hidden" />
              <img
                className="h-[23px] w-[23px] relative overflow-hidden shrink-0 min-h-[23px] z-[3]"
                loading="lazy"
                alt=""
                src="/plus-circle.svg"
              />
              <div className="flex flex-col items-start justify-start pt-[3px] px-0 pb-0">
                <div className="relative inline-block min-w-[60px] z-[3]">
                  添加商品
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch grid flex-row items-start justify-start gap-[51px] grid-cols-[repeat(3,_minmax(115px,_1fr))] text-smi mq450:grid-cols-[minmax(115px,_1fr)] mq825:gap-[25px] mq825:justify-center mq825:grid-cols-[repeat(2,_minmax(115px,_200px))]">
            <ItemOne />
            <div className="shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 relative gap-[3px] z-[2]">
              <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden z-[0]" />
              <div className="relative inline-block min-w-[39px] max-w-[28%] z-[3]">
                商品名
              </div>
              <div className="relative inline-block min-w-[26px] max-w-[19%] z-[3]">
                价格
              </div>
              <div className="!m-[0] absolute top-[-9px] right-[-16px] flex flex-row items-start justify-start py-0 pr-2.5 pl-0 text-5xl text-background-default-default">
                <div className="h-8 w-8 relative rounded-[50%] bg-red-200 z-[3]" />
                <div className="flex flex-col items-start justify-start pt-[3px] px-0 pb-0 ml-[-22px]">
                  <div className="relative inline-block min-w-[12px] z-[4] mq450:text-lgi">
                    1
                  </div>
                </div>
              </div>
            </div>
            <div className="shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 gap-[3px] z-[2]">
              <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
              <div className="relative inline-block min-w-[39px] max-w-[28%] z-[3]">
                商品名
              </div>
              <div className="relative inline-block min-w-[26px] max-w-[19%] z-[3]">
                价格
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[47px] text-smi mq825:flex-wrap mq825:gap-[23px]">
            <div className="flex-1 flex flex-col items-start justify-start py-0 pr-2 pl-0 box-border min-w-[121px]">
              <div className="self-stretch shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 gap-[3px] z-[2]">
                <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
                <div className="relative inline-block min-w-[39px] z-[3]">
                  商品名
                </div>
                <div className="relative inline-block min-w-[26px] z-[3]">
                  价格
                </div>
              </div>
            </div>
            <div className="flex-1 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 box-border gap-[3px] min-w-[115px] z-[2]">
              <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
              <div className="relative inline-block min-w-[39px] z-[3]">
                商品名
              </div>
              <div className="relative inline-block min-w-[26px] z-[3]">
                价格
              </div>
            </div>
            <div className="flex-1 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 box-border gap-[3px] min-w-[115px] z-[2]">
              <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
              <div className="relative inline-block min-w-[39px] z-[3]">
                商品名
              </div>
              <div className="relative inline-block min-w-[26px] z-[3]">
                价格
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="self-stretch flex flex-col items-start justify-start gap-[32px] max-w-full mq825:gap-[16px]">
        <div className="flex flex-row items-start justify-start py-0 px-1">
          <div className="flex flex-row items-start justify-start gap-[14px]">
            <h1 className="m-0 w-24 relative text-inherit font-normal font-inherit inline-block z-[2] mq450:text-lgi mq825:text-7xl">
              共计：
            </h1>
            <div className="relative text-red-200 inline-block min-w-[120px] z-[2] mq450:text-lgi mq825:text-7xl">
              ￥00.00
            </div>
          </div>
        </div>
        <div className="self-stretch rounded-3xs bg-black-100 flex flex-row items-start justify-center pt-[9px] px-5 pb-2.5 box-border max-w-full z-[2] text-background-default-default">
          <div className="h-[58px] w-[564px] relative rounded-3xs bg-black-100 hidden max-w-full" />
          <h1 className="m-0 relative text-inherit font-normal font-inherit inline-block min-w-[64px] z-[3] mq450:text-lgi mq825:text-7xl">
            结账
          </h1>
        </div>
      </div>
    </div>
  );
};

TableInfo.propTypes = {
  className: PropTypes.string,
};

export default TableInfo;
