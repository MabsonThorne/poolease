import OrderItems from "./OrderItems";
import ProductGridExtended from "./ProductGridExtended";
import PropTypes from "prop-types";

const ProductCarousel = ({ className = "" }) => {
  return (
    <div
      className={`w-[647px] rounded-xl bg-background-default-default flex flex-col items-start justify-start pt-12 pb-[94px] pr-[38px] pl-10 box-border gap-[52.5px] min-w-[647px] max-w-full z-[1] text-left text-13xl text-black-100 font-body-base mq1150:flex-1 mq750:gap-[26px] mq1050:pt-[31px] mq1050:pb-[61px] mq1050:box-border mq1050:min-w-full mq450:pt-5 mq450:pb-10 mq450:box-border ${className}`}
    >
      <div className="w-[647px] h-[905px] relative rounded-xl bg-background-default-default hidden max-w-full" />
      <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-0.5 box-border max-w-full">
        <div className="flex-1 flex flex-col items-start justify-start gap-[12px] max-w-full">
          <div className="w-[336px] flex flex-row items-start justify-start py-0 px-2 box-border max-w-full">
            <div className="h-[39px] flex-1 relative leading-[39.2px] inline-block z-[2] mq450:text-base">
              <span>请选择商品</span>
              <span className="text-xl">（左滑选择更多）</span>
            </div>
          </div>
          <img
            className="self-stretch relative max-w-full overflow-hidden max-h-full object-contain mt-[-1px] z-[2]"
            alt=""
          />
        </div>
      </div>
      <OrderItems propPadding="unset" />
      <ProductGridExtended />
    </div>
  );
};

ProductCarousel.propTypes = {
  className: PropTypes.string,
};

export default ProductCarousel;
