import PropTypes from "prop-types";

const PasswordInput = ({ className = "" }) => {
  return (
    <div
      className={`flex-1 rounded-xl bg-background-default-default flex flex-col items-end justify-start pt-14 pb-[77px] pr-[68px] pl-[43px] box-border gap-[51px] min-w-[442px] max-w-full z-[1] text-left text-13xl text-background-default-default font-body-base mq450:pt-[23px] mq450:pb-8 mq450:box-border mq750:gap-[25px] mq750:pl-[21px] mq750:pr-[34px] mq750:box-border mq750:min-w-full mq1050:pt-9 mq1050:pb-[50px] mq1050:box-border ${className}`}
    >
      <div className="w-[680px] h-[905px] relative rounded-xl bg-background-default-default hidden max-w-full" />
      <div className="self-stretch flex flex-col items-start justify-start pt-0 px-0 pb-3 box-border gap-[29px] max-w-full text-black-100">
        <div className="self-stretch flex flex-row items-start justify-center py-0 pr-5 pl-10">
          <div className="relative z-[2] mq450:text-lgi mq1050:text-7xl">
            请选择台号
          </div>
        </div>
        <div className="self-stretch rounded-3xs bg-background-default-default box-border flex flex-row items-start justify-start pt-3 px-[15px] pb-[7px] max-w-full z-[2] border-[1px] border-solid border-black-100">
          <div className="h-[62px] w-[564px] relative rounded-3xs bg-background-default-default box-border hidden max-w-full border-[1px] border-solid border-black-100" />
          <input
            className="w-[244px] [border:none] [outline:none] font-body-base text-13xl bg-[transparent] h-[39px] relative text-gray-200 text-left inline-block p-0 z-[3] mq450:text-lgi mq1050:text-7xl"
            placeholder="请输入6位数密码"
            type="text"
          />
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 px-11 box-border max-w-full text-29xl text-background-default-default mq750:pl-[22px] mq750:pr-[22px] mq750:box-border">
          <div className="flex-1 flex flex-row items-start justify-start gap-[49px] max-w-full mq750:flex-wrap mq750:gap-[24px]">
            <div className="flex-[0.7188] rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] pr-[51px] pl-[52px] box-border min-w-[31px] z-[2] mq450:flex-1">
              <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
              <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
                1
              </div>
            </div>
            <div className="flex-[0.9375] rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] px-12 box-border min-w-[31px] z-[2] mq450:flex-1">
              <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
              <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
                2
              </div>
            </div>
            <div className="flex-1 rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] px-[47px] box-border min-w-[31px] z-[2]">
              <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
              <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
                3
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="self-stretch flex flex-row items-start justify-end py-0 pr-11 pl-[49px] box-border max-w-full text-29xl mq750:pl-6 mq750:pr-[22px] mq750:box-border">
        <div className="w-[476px] flex flex-row flex-wrap items-start justify-start gap-[63px_47px] min-h-[315px] max-w-full mq750:gap-[23px]">
          <div className="w-[126px] rounded-3xs bg-lightgray flex flex-row items-start justify-end py-[34px] px-[43px] box-border z-[2]">
            <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
            <div className="relative inline-block min-w-[31px] z-[3] mq450:text-10xl mq1050:text-19xl">
              4
            </div>
          </div>
          <div className="w-[126px] rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] px-12 box-border z-[2]">
            <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
            <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
              5
            </div>
          </div>
          <div className="w-[126px] rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] px-[47px] box-border z-[2]">
            <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
            <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
              6
            </div>
          </div>
          <div className="rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] pr-[46px] pl-[52px] z-[2]">
            <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
            <div className="relative inline-block min-w-[28px] z-[3] mq450:text-10xl mq1050:text-19xl">
              7
            </div>
          </div>
          <div className="w-[126px] rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] px-12 box-border z-[2]">
            <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
            <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
              8
            </div>
          </div>
          <div className="w-[126px] rounded-3xs bg-lightgray flex flex-row items-start justify-start py-[34px] px-[47px] box-border z-[2]">
            <div className="h-[126px] w-[126px] relative rounded-3xs bg-lightgray hidden" />
            <div className="flex-1 relative z-[3] mq450:text-10xl mq1050:text-19xl">
              9
            </div>
          </div>
        </div>
      </div>
      <div className="self-stretch flex flex-row items-start justify-end py-0 pr-[5px] pl-0 box-border max-w-full">
        <div className="flex-1 rounded-3xs bg-black-100 flex flex-row items-start justify-center pt-[9px] px-5 pb-2.5 box-border max-w-full z-[2]">
          <div className="h-[58px] w-[564px] relative rounded-3xs bg-black-100 hidden max-w-full" />
          <div className="relative inline-block min-w-[64px] z-[3] mq450:text-lgi mq1050:text-7xl">
            开台
          </div>
        </div>
      </div>
    </div>
  );
};

PasswordInput.propTypes = {
  className: PropTypes.string,
};

export default PasswordInput;
