import { useMemo } from "react";
import PropTypes from "prop-types";

const OrderItems = ({ className = "", propPadding }) => {
  const orderItemsStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  return (
    <div
      className={`self-stretch flex flex-row items-start justify-start gap-[49px] text-left text-smi text-black-100 font-body-base mq750:flex-wrap mq750:gap-[24px] ${className}`}
      style={orderItemsStyle}
    >
      <div className="flex-1 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 box-border gap-[3px] min-w-[115px] z-[2]">
        <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
        <div className="relative inline-block min-w-[39px] z-[3]">商品名</div>
        <div className="relative inline-block min-w-[26px] z-[3]">价格</div>
      </div>
      <div className="flex-1 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 box-border gap-[3px] min-w-[115px] z-[2]">
        <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
        <div className="relative inline-block min-w-[39px] z-[3]">商品名</div>
        <div className="relative inline-block min-w-[26px] z-[3]">价格</div>
      </div>
      <div className="flex-1 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default flex flex-col items-start justify-end pt-[136px] px-1.5 pb-2.5 box-border gap-[3px] min-w-[115px] z-[2]">
        <div className="w-[154px] h-[181px] relative shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-3xs bg-background-default-default hidden" />
        <div className="relative inline-block min-w-[39px] z-[3]">商品名</div>
        <div className="relative inline-block min-w-[26px] z-[3]">价格</div>
      </div>
    </div>
  );
};

OrderItems.propTypes = {
  className: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
};

export default OrderItems;
