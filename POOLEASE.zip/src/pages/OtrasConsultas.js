import React from "react";
import FrameComponent1 from "../components/FrameComponent1";
import TableSelection from "../components/TableSelection";
import TableInfo from "../components/TableInfo";

const OtrasConsultas = () => {
  return (
    <div className="w-full h-[1024px] relative rounded-xl bg-background-default-default overflow-hidden flex flex-col items-start justify-start gap-[218px] leading-[normal] tracking-[normal] text-left text-13xl text-background-default-default font-body-base lg:h-auto mq450:gap-[54px] mq825:gap-[109px]">
      <main className="self-stretch flex flex-col items-start justify-start shrink-0 max-w-full">
        <FrameComponent1 />
        <section className="self-stretch bg-whitesmoke flex flex-row items-start justify-start pt-3.5 px-9 pb-[35px] box-border gap-[39px] max-w-full lg:flex-wrap lg:pt-5 lg:pb-[23px] lg:box-border mq825:gap-[19px] mq825:pb-5 mq825:box-border">
          <TableSelection headerSeparator="/header-separator.svg" className="flex-1" />
          <TableInfo className="flex-1" />
        </section>
      </main>
    </div>
  );
};

export default OtrasConsultas;
