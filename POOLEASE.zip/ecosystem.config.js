const path = require('path');

module.exports = {
  apps: [
    {
      name: 'poolease-backend',
      script: './backend/app.js',
      cwd: './',
      env: {
        NODE_ENV: 'development',
        PORT: 3001,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3001,
      },
    },
    {
      name: 'poolease-frontend',
      script: path.resolve(__dirname, 'node_modules', '.bin', 'react-scripts.cmd'),
      args: 'start',
      cwd: './',
      interpreter: 'cmd.exe',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
    },
    {
      name: 'poolease-electron',
      script: path.resolve(__dirname, 'node_modules', 'electron', 'electron.exe'),
      args: '.',
      cwd: './',
      env: {
        NODE_ENV: 'development',
      },
      env_production: {
        NODE_ENV: 'production',
      },
    },
  ],
};
